package com.example.activitynavigation

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.TextView

class FirstActivity : AppCompatActivity() {

    private lateinit var mFirstActivityMessage: TextView


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_first)

        mFirstActivityMessage = findViewById(R.id.first_activity_text)
        mFirstActivityMessage.text = intent.getStringExtra("msg")

        Log.i("App","[First Activity] OnCreate() ")
    }

    override fun onStart() {
        super.onStart()
        Log.i("App","[First Activity] OnStart() ")
    }

    override fun onRestart() {
        super.onRestart()
        Log.i("App","[First Activity] OnRestart() ")
    }

    override fun onResume() {
        super.onResume()
        Log.i("App","[First Activity] OnResume() ")
    }

    override fun onPause() {
        super.onPause()
        Log.i("App","[First Activity] OnPause() ")
    }

    override fun onStop() {
        super.onStop()
        Log.i("App","[First Activity] OnStop() ")
    }

    override fun onDestroy() {
        super.onDestroy()
        Log.i("App","[First Activity] OnDestroy() ")
    }
}
