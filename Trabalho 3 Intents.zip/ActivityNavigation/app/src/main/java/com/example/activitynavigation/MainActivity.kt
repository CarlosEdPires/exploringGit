package com.example.activitynavigation

import android.content.Intent
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.provider.CalendarContract
import android.util.Log
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import java.util.*

class MainActivity : AppCompatActivity(), View.OnClickListener {

    private lateinit var mFirstActivityButton: Button
    private lateinit var mSecondActivityButton: Button
    private lateinit var mTextEdit: EditText
    private val SECOND_ACTIVITY_ID = 1
    private lateinit var mFeedback: TextView
    private lateinit var mMapButton: Button
    private lateinit var mDateButton: Button
    private lateinit var mWebButton: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        mFirstActivityButton = findViewById(R.id.button_activity1)
        mFirstActivityButton.setOnClickListener(this)

        mSecondActivityButton = findViewById((R.id.button_activity2))
        mSecondActivityButton.setOnClickListener(this)

        mMapButton = findViewById(R.id.map_button)
        mMapButton.setOnClickListener(this)

        mDateButton = findViewById(R.id.date_button)
        mDateButton.setOnClickListener(this)

        mWebButton = findViewById(R.id.web_button)
        mWebButton.setOnClickListener(this)

        mTextEdit = findViewById((R.id.main_text_edit))
        mTextEdit.setOnClickListener(this)

        mFeedback = findViewById(R.id.main_feedback_message)
        mFeedback.setOnClickListener(this)

        Log.i("App","[Main Activity] OnCreate() ")
    }

    override fun onStart() {
        super.onStart()
        Log.i("App","[Main Activity] OnStart() ")
    }

    override fun onRestart() {
        super.onRestart()
        Log.i("App","[Main Activity] OnRestart() ")
    }

    override fun onResume() {
        super.onResume()
        Log.i("App","[Main Activity] OnResume() ")
    }

    override fun onPause() {
        super.onPause()
        Log.i("App","[Main Activity] OnPause() ")
    }

    override fun onStop() {
        super.onStop()
        Log.i("App","[Main Activity] OnStop() ")
    }

    override fun onDestroy() {
        super.onDestroy()
        Log.i("App","[Main Activity] OnDestroy() ")
    }

    override fun onClick(v: View?) {

        when(v?.id){

            R.id.button_activity1 -> {
                //Toast.makeText(this,"First button clicked!", Toast.LENGTH_SHORT).show()
                val it = Intent(this, FirstActivity::class.java)

                it.putExtra("msg", mTextEdit.text.toString())
                startActivity(it)
            }

            R.id.button_activity2 -> {
                //Toast.makeText(this,"Second button clicked!", Toast.LENGTH_SHORT).show()
                val it = Intent(this, SecondActivity::class.java)

                it.putExtra("msg", mTextEdit.text.toString())
                startActivityForResult(it, SECOND_ACTIVITY_ID)
            }

            R.id.map_button->{

                val intent = Intent(Intent.ACTION_VIEW).apply {
                    val unifor = "geo:-3.768765, -38.478577"
                    data = Uri.parse(unifor)
                }
                if (intent.resolveActivity(packageManager) != null) {
                    startActivity(intent)
                }
                //val it = Intent(Intent.ACTION_SEND ).apply {

                    //type = "*/*"
                    //putExtra(Intent.EXTRA_EMAIL, arrayOf("edu@gmay.com"))
                    //putExtra(Intent.EXTRA_SUBJECT, "email de teste")
                    //putExtra(Intent.EXTRA_STREAM, Uri.encode("Teste de email de extra_stream"))
                //}
                //if(intent.resolveActivity(packageManager) != null){
                    //startActivity(it)
               // }

            }

            R.id.date_button->{

                val intent = Intent(Intent.ACTION_INSERT).apply {

                    val startMillis: Long = Calendar.getInstance().run {
                        set(2020,6,23,0,0)
                        timeInMillis
                    }

                    val endMillis: Long = Calendar.getInstance().run {
                        set(2020, 6, 23, 8, 0)
                        timeInMillis
                    }
                    data = CalendarContract.Events.CONTENT_URI
                    putExtra(CalendarContract.Events.TITLE, "Dormir")
                    putExtra(CalendarContract.Events.EVENT_LOCATION, "Casa")
                    putExtra(CalendarContract.EXTRA_EVENT_BEGIN_TIME, startMillis)
                    putExtra(CalendarContract.EXTRA_EVENT_END_TIME, endMillis)
                }
                if (intent.resolveActivity(packageManager) != null) {
                    startActivity(intent)
                }


            }

            R.id.web_button->{

                val webpage: Uri = Uri.parse("https:www.unifor.br")
                val intent = Intent(Intent.ACTION_VIEW, webpage)
                if (intent.resolveActivity(packageManager) != null) {
                    startActivity(intent)
                }

            }
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        when(requestCode){
            SECOND_ACTIVITY_ID ->{

                val msg = data?.getStringExtra("second_msg")

                mFeedback.text = msg
            }
        }
    }
}
