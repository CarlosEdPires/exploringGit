package com.example.activitynavigation

import android.app.Activity
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast

class SecondActivity : AppCompatActivity() {

    private lateinit var mSecondActivityMessage: TextView
    private lateinit var mSecondEditText: EditText
    private lateinit var mSendButton: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_second)

        mSecondActivityMessage = findViewById(R.id.second_activity_text)
        mSecondActivityMessage.text = intent.getStringExtra("msg")
        mSecondEditText = findViewById(R.id.second_text_edit)
        mSendButton = findViewById(R.id.send_button)

        mSendButton.setOnClickListener{

            val msg = mSecondEditText.text.toString()

            if(!msg.isEmpty()){

                val it = Intent()
                it.putExtra("second_msg", msg)
                setResult(Activity.RESULT_OK, it)
                finish()
            }else{
                mSecondEditText.error = "Campo Vazio!"
                Toast.makeText(this,"Digite Algo!", Toast.LENGTH_SHORT).show()
            }
        }

        Log.i("App","[Second Activity] OnCreate() ")
    }

    override fun onStart() {
        super.onStart()
        Log.i("App","[Second Activity] OnStart() ")
    }

    override fun onRestart() {
        super.onRestart()
        Log.i("App","[Second Activity] OnRestart() ")
    }

    override fun onResume() {
        super.onResume()
        Log.i("App","[Second Activity] OnResume() ")
    }

    override fun onPause() {
        super.onPause()
        Log.i("App","[Second Activity] OnPause() ")
    }

    override fun onStop() {
        super.onStop()
        Log.i("App","[Second Activity] OnStop() ")
    }

    override fun onDestroy() {
        super.onDestroy()
        Log.i("App","[Second Activity] OnDestroy() ")
    }
}
