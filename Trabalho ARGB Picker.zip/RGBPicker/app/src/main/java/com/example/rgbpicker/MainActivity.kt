package com.example.rgbpicker

import android.graphics.Color
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.SeekBar

class MainActivity : AppCompatActivity(), SeekBar.OnSeekBarChangeListener {

    private lateinit var mColorView: View
    private lateinit var mColorSeekBarA: SeekBar
    private lateinit var mColorSeekBarB: SeekBar
    private lateinit var mColorSeekBarC: SeekBar
    private lateinit var mColorSeekBarD: SeekBar
    private var brightness = 255
    private var red = 0
    private var green = 0
    private var blue = 0


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        mColorView = findViewById(R.id.main_view_color)

        mColorSeekBarA = findViewById((R.id.seekbar_brightness))
        mColorSeekBarA.setOnSeekBarChangeListener(this)
        mColorSeekBarB = findViewById((R.id.seekbar_red))
        mColorSeekBarB.setOnSeekBarChangeListener(this)
        mColorSeekBarC = findViewById((R.id.seekbar_green))
        mColorSeekBarC.setOnSeekBarChangeListener(this)
        mColorSeekBarD = findViewById((R.id.seekbar_blue))
        mColorSeekBarD.setOnSeekBarChangeListener(this)
    }

    override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {

        when(seekBar?.id){
            R.id.seekbar_brightness ->{

                brightness = progress
            }

            R.id.seekbar_red ->{

                red = progress
            }

            R.id.seekbar_green ->{

                green = progress
            }

            R.id.seekbar_blue ->{

                blue = progress
            }
        }

        mColorView.setBackgroundColor(Color.argb(brightness,red,green,blue))
    }

    override fun onStartTrackingTouch(seekBar: SeekBar?) {
    }

    override fun onStopTrackingTouch(seekBar: SeekBar?) {
    }
}
